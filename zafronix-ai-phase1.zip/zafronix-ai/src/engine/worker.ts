/**
 * Processing worker. All heavy work (decode, neural network, encode, mux) happens here so the
 * page stays responsive. One job at a time; cancelling a job terminates the whole worker,
 * which releases the decoder, encoder and GPU device immediately.
 */
import type { MainToWorker, WorkerToMain } from './protocol';
import { runVideoJob } from './video-job';
import { runImageJob } from './image-job';
import { toJobError } from '../lib/errors';

const scope = self as unknown as {
  postMessage(message: unknown, transfer?: Transferable[]): void;
  onmessage: ((event: MessageEvent<MainToWorker>) => void) | null;
};

let busy = false;

// Remembered only so a failure report can say how far the job got.
let lastStage = 'start';
let lastFrames = 0;

function post(message: WorkerToMain, transfer: Transferable[] = []): void {
  if (message.type === 'stage') lastStage = message.stage;
  else if (message.type === 'progress') lastFrames = message.framesDone ?? 0;
  scope.postMessage(message, transfer);
}

/** One line of technical detail for bug reports: what was thrown, how far it got, where. */
function describe(e: unknown): string {
  const any = e as { name?: unknown; message?: unknown; stack?: unknown; type?: unknown } | null;
  const name = String(any?.name ?? any?.type ?? typeof e);
  const message = String(any?.message ?? (typeof e === 'string' ? e : ''));
  const stack = String(any?.stack ?? '').split('\n').slice(0, 4).join(' | ').slice(0, 600);
  return `${name}: ${message} | stage=${lastStage} frames=${lastFrames}${stack ? ' | ' + stack : ''}`;
}

scope.onmessage = async (event) => {
  const req = event.data;
  if (!req || typeof req !== 'object' || !('type' in req)) return;

  if (busy) {
    post({ type: 'error', jobId: req.jobId, code: 'invalid-input', message: 'A job is already running.' });
    return;
  }
  busy = true;
  lastStage = 'start';
  lastFrames = 0;
  try {
    if (req.type === 'video') await runVideoJob(req, post);
    else if (req.type === 'image') await runImageJob(req, post);
  } catch (e) {
    const err = toJobError(e);
    console.error('[zafronix worker]', e);
    post({ type: 'error', jobId: req.jobId, code: err.code, message: err.message, hint: err.hint, detail: describe(e) });
  } finally {
    busy = false;
  }
};

post({ type: 'boot' });
