const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');

/**
 * Build output goes to ./dist (this is the Netlify "publish" directory).
 *
 * Heavy processing lives in a Web Worker (src/engine/worker.ts). Webpack 5 picks it up
 * automatically from `new Worker(new URL('./worker.ts', import.meta.url))`.
 *
 * ts-loader runs with transpileOnly so a type error can never break a production deploy.
 * Type safety is checked separately with `npm run type-check`.
 */
module.exports = (env, argv) => {
  const isProd = argv.mode === 'production';

  return {
    entry: { main: './src/index.ts' },

    output: {
      path: path.resolve(__dirname, 'dist'),
      filename: isProd ? '[name].[contenthash:8].js' : '[name].js',
      chunkFilename: isProd ? '[name].[contenthash:8].js' : '[name].js',
      publicPath: 'auto',
      clean: true,
    },

    devtool: isProd ? false : 'source-map',

    module: {
      rules: [
        {
          test: /\.ts$/,
          exclude: /node_modules/,
          loader: 'ts-loader',
          options: { transpileOnly: true },
        },
      ],
    },

    resolve: { extensions: ['.ts', '.js'] },

    plugins: [
      new HtmlWebpackPlugin({
        template: 'src/index.html',
        scriptLoading: 'defer',
        minify: isProd,
      }),
      new CopyWebpackPlugin({
        patterns: [
          // styles, favicon, 404, robots, model weights ...
          { from: 'public', to: '.', globOptions: { ignore: ['**/.DS_Store'] } },
          // Demuxer WASM, served from our own origin (no CDN dependency at runtime).
          {
            from: 'node_modules/web-demuxer/dist/wasm-files/*.wasm',
            to: 'wasm/[name][ext]',
            noErrorOnMissing: true,
          },
        ],
      }),
    ],

    performance: { hints: false },

    devServer: {
      port: 8080,
      hot: false,
      compress: true,
      allowedHosts: 'all',
      client: { overlay: true },
    },
  };
};
