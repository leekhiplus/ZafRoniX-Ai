/** Hero before/after illustration. It is drawn in code, so it is NOT a real result. */

function scene(ctx: CanvasRenderingContext2D, w: number, h: number): void {
  const sky = ctx.createLinearGradient(0, 0, 0, h);
  sky.addColorStop(0, '#0d1b4a');
  sky.addColorStop(0.55, '#4a3a9a');
  sky.addColorStop(1, '#e0708a');
  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, w, h);

  // sun
  const sun = ctx.createRadialGradient(w * 0.68, h * 0.5, 0, w * 0.68, h * 0.5, h * 0.2);
  sun.addColorStop(0, '#fff3c4');
  sun.addColorStop(1, 'rgba(255,200,120,0)');
  ctx.fillStyle = sun;
  ctx.fillRect(0, 0, w, h);

  // stars
  ctx.fillStyle = '#fff';
  for (let i = 0; i < 40; i++) {
    const x = ((i * 9301 + 49297) % 233280) / 233280 * w;
    const y = ((i * 7919 + 12345) % 233280) / 233280 * h * 0.4;
    ctx.fillRect(x, y, Math.max(1, w / 500), Math.max(1, w / 500));
  }

  // mountains
  const ridge = (base: number, amp: number, color: string, seed: number) => {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(0, h);
    for (let x = 0; x <= w; x += w / 48) {
      const y = base + Math.sin(x / w * 7 + seed) * amp + Math.sin(x / w * 17 + seed * 2) * amp * 0.35;
      ctx.lineTo(x, y);
    }
    ctx.lineTo(w, h);
    ctx.closePath();
    ctx.fill();
  };
  ridge(h * 0.62, h * 0.07, '#3a2a7a', 1);
  ridge(h * 0.72, h * 0.06, '#241a58', 3);
  ridge(h * 0.84, h * 0.04, '#120d33', 5);

  // fine detail lines so the sharp side looks different
  ctx.strokeStyle = 'rgba(255,255,255,0.35)';
  ctx.lineWidth = Math.max(1, w / 900);
  for (let i = 0; i < 14; i++) {
    const y = h * (0.66 + i * 0.02);
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(w, y);
    ctx.globalAlpha = 0.12;
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
}

export function initDemo(): void {
  const root = document.getElementById('demo');
  const after = document.getElementById('demo-after') as HTMLCanvasElement | null;
  const before = document.getElementById('demo-before') as HTMLCanvasElement | null;
  const range = document.getElementById('demo-range') as HTMLInputElement | null;
  if (!root || !after || !before || !range) return;

  const a = after.getContext('2d');
  const b = before.getContext('2d');
  if (!a || !b) return;
  scene(a, after.width, after.height);

  // "Before": the same scene drawn tiny, then shown enlarged and pixelated.
  const tiny = document.createElement('canvas');
  tiny.width = 64;
  tiny.height = 40;
  const t = tiny.getContext('2d');
  if (!t) return;
  scene(t, tiny.width, tiny.height);
  b.imageSmoothingEnabled = false;
  b.drawImage(tiny, 0, 0, before.width, before.height);

  const set = () => root.style.setProperty('--pos', `${range.value}%`);
  range.addEventListener('input', set);
  set();
}
