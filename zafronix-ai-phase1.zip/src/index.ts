import { boot } from './app/app';
import { initDemo } from './ui/demo';

try {
  initDemo();
} catch (e) {
  console.warn('[Leekhi Ai] demo skipped', e);
}
boot();
